# Versions

## 1.1.0
* Fixed an issue where skins were not visible

## 1.0.0
* Added 40 skins

# Skins

## Series
* Finn - from "jombi-SuitsAndCosmetics"
* Goku - from "KingTyphon-AnimeSkins"
* Killer Bee - from "BoxCreations-Box_More_Suits"
* Luffy - from "CHILLAX-Chillax_Suits"
* Pikachu - from "jombi-SuitsAndCosmetics"
* Puss In Boots - from "BoxCreations-Box_More_Suits"
* Saitama - from "BoxCreations-Box_More_Suits"
* Snorlax - from "BoxCreations-Box_More_Suits"
* Spider Man - from "Stoners-SpiderManSuitV2"
* Zoro - from "BoxCreations-Box_More_Suits"

## Games
* Among Us Blue - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Among Us Lime - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Among Us Orange - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Among Us Pink - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Among Us Red - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Among Us White - from "CoNcept_Temple_Modding-Among_Us_Suits"
* Hoarding Bug - from "Fatcat-More_Suits_Fat_Cat_Alliance_Edition"
* Vault Boy - from "TeamClark-Vault_Boy_Suit"

## Colors - from "PhantomDergwulf-Dergs_Suits"

* Black
* Blue
* Cyan
* Dark Blue
* Green
* Grey
* Lime
* Magenta
* Pink
* Red
* White
* Yellow

## Random
* Clown Suit - from "Crabford-Clown_Suit"
* Fat Cat - from "Fatcat-More_Suits_Fat_Cat_Alliance_Edition"
* Artic - from "Dwarggo-Fashion_Company"
* Dog - from "Dwarggo-Fashion_Company"
* Elite - from "Dwarggo-Fashion_Company"
* Highclass - from "Dwarggo-Fashion_Company"
* Hightech - from "Dwarggo-Fashion_Company"
* Reclaimed - from "Dwarggo-Fashion_Company"
* Speedster - from "Dwarggo-Fashion_Company"
* Workout - from "Dwarggo-Fashion_Company"